mount -o rw,remount -t yaffs2 /dev/block/mtdblock11 /system
rm /system/xbin/su
rm /system/bin/su
mkdir /system/xbin
cat /superboot/su>/system/xbin/su
chmod 4755 /system/xbin/su
cat /superboot/Superuser.apk>/system/app/Superuser.apk
