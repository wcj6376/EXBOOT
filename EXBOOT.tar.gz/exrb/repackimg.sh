#!/system/bin/sh

DATA_WORK=$PWD #当前路径
repack_type=$1 #第一个参数
BOOT_DIR=$2 #第二个参数
bin=$DATA_WORK/bin
bb=$bin/busybox

#打包mtk的boot/rec
function mtk_repackimg()
{
cd $DATA_WORK/$BOOT_DIR
echo "打包 ramdisk..."
if [ -z "$(ls $DATA_WORK/${BOOT_DIR%.*}/* 2> /dev/null)" -o -z "$(ls $DATA_WORK/${BOOT_DIR%.*}/${BOOT_DIR%.*}.img-ramdisk/* 2> /dev/null)" ]; then
  echo "需要打包的文件未就绪！";
  return 1;
fi;

cd $DATA_WORK/${BOOT_DIR%.*}


ramdiskcomp=`cat *-ramdiskcomp`;

echo " $ramdiskcomp 方式打包 ramdisk..."

    repackcmd="$bb $ramdiskcomp";
    compext=$ramdiskcomp;
    case $ramdiskcomp in
      gzip) compext=gz;;
      lzop) compext=lzo;;
      xz) repackcmd="$bin/xz -1 -Ccrc32";;
      lzma) repackcmd="$bin/xz -Flzma";;
      bzip2) compext=bz2;;
      lz4) repackcmd="$bin/call $bin lz4 -l stdin stdout";;
    esac;

cd ${BOOT_DIR%.*}.img-ramdisk
#$bb find . | $bb cpio -o -H newc | $repackcmd > ../ramdisk
$bin/call $bin mkbootfs . | > ../ramdisk $repackcmd 
cd ..
    if [ $? == "1" ]; then
      echo "打包ramdisk失败！"
      return 1;
    fi
#echo "向ramdisk添加512字节头..."

$bin/call $bin revise ramdisk ${BOOT_DIR%.*}.img-ramdisk.gz 
echo "获取信息...\n"
kernel=`ls *-zImage`;               echo "kernel = $kernel"
ramdisk=`ls *-ramdisk.$compext`;     
echo "ramdisk = $ramdisk";
cmdline=`cat *-cmdline`;            echo "cmdline = $cmdline";
board=`cat *-board`;                echo "board = $board";
base=`cat *-base`;                  echo "base = $base";
pagesize=`cat *-pagesize`;          echo "pagesize = $pagesize";
kerneloff=`cat *-kerneloff`;        echo "kernel_offset = $kerneloff";
ramdiskoff=`cat *-ramdiskoff`;      
echo "ramdisk_offset = $ramdiskoff";
tagsoff=`cat *-tagsoff`;            echo "tags_offset = $tagsoff";
if [ -f *-second ]; then
  second=`ls *-second`;             echo "second = $second";  
  second=--second $second
  secondoff=`cat *-secondoff`;      
echo "second_offset = $secondoff";
  secondoff="--second_offset $secondoff";
fi;

if [ -f *-dtb ]; then
  dtb=`ls *-dtb`;                   echo "dtb = $dtb";
  dtb="--dt $dtb";
fi;

#echo "打包中..."

$bin/call $bin mkbootimg --output image-new.img --kernel "$kernel" --ramdisk "$ramdisk" $second --cmdline "$cmdline" --board "$board" --base $base --pagesize $pagesize --kernel_offset $kerneloff --ramdisk_offset $ramdiskoff $secondoff --tags_offset $tagsoff $dtb

if [ $? == "1" ]; then
  echo "打包失败！"
  return 1;
fi;
$bb cp image-new.img ../
echo "打包完成!"
}

#打包其他通用机型的boot/rec
function common_repackimg()
{
cd $DATA_WORK/$BOOT_DIR
#echo "打包ramdisk..."
[ -f ${BOOT_DIR%.*}.img-ramdisk.gz ] && $bb rm -r ${BOOT_DIR%.*}.img-ramdisk.gz
if [ -z "$(ls $DATA_WORK/${BOOT_DIR%.*}/* 2> /dev/null)" -o -z "$(ls $DATA_WORK/${BOOT_DIR%.*}/${BOOT_DIR%.*}.img-ramdisk/* 2> /dev/null)" ]; then
  echo "需要打包的文件未就绪！";
  return 1;
fi;

cd $DATA_WORK/${BOOT_DIR%.*}

[ -f $DATA_WORK/${BOOT_DIR%.*}.img-ramdisk.gz ] && $bb rm -r ${BOOT_DIR%.*}.img-ramdisk.gz

ramdiskcomp=`cat *-ramdiskcomp`;

echo " $ramdiskcomp 方式打包 ramdisk..."

    repackcmd="$bb $ramdiskcomp";
    compext=$ramdiskcomp;
    case $ramdiskcomp in
      gzip) compext=gz;;
      lzop) compext=lzo;;
      xz) repackcmd="$bin/xz -1 -Ccrc32";;
      lzma) repackcmd="$bin/xz -Flzma";;
      bzip2) compext=bz2;;
      lz4) repackcmd="$bin/call $bin lz4 -l stdin stdout";;
    esac;

cd ${BOOT_DIR%.*}.img-ramdisk
#$bb find . | $bb cpio -o -H newc | $repackcmd > ../${BOOT_DIR%.*}.img-ramdisk.gz
$bin/call $bin mkbootfs . | $repackcmd > ../${BOOT_DIR%.*}.img-ramdisk.gz
cd ..
    if [ $? == "1" ]; then
      echo "打包 ramdisk 失败！"
      return 1;
    fi
echo "获取信息...\n"
kernel=`ls *-zImage`;               echo "kernel = $kernel"
ramdisk=`ls *-ramdisk.$compext`;     
echo "ramdisk = $ramdisk";
cmdline=`cat *-cmdline`;            echo "cmdline = $cmdline";
board=`cat *-board`;                echo "board = $board";
base=`cat *-base`;                  echo "base = $base";
pagesize=`cat *-pagesize`;          echo "pagesize = $pagesize";
kerneloff=`cat *-kerneloff`;        echo "kernel_offset = $kerneloff";
ramdiskoff=`cat *-ramdiskoff`;      
echo "ramdisk_offset = $ramdiskoff";
tagsoff=`cat *-tagsoff`;            echo "tags_offset = $tagsoff";
if [ -f *-second ]; then
  second=`ls *-second`;             echo "second = $second";  
  second=--second $second
  secondoff=`cat *-secondoff`;      
echo "second_offset = $secondoff";
  secondoff="--second_offset $secondoff";
fi;

if [ -f *-dtb ]; then
  dtb=`ls *-dtb`;                   echo "dtb = $dtb";
  dtb="--dt $dtb";
fi;

#echo "打包中..."

$bin/call $bin mkbootimg --output image-new.img --kernel "$kernel" --ramdisk "$ramdisk" $second --cmdline "$cmdline" --board "$board" --base $base --pagesize $pagesize --kernel_offset $kerneloff --ramdisk_offset $ramdiskoff $secondoff --tags_offset $tagsoff $dtb

if [ $? == "1" ]; then
  echo "打包失败！"
  return 1;
fi;
$bb cp image-new.img ../
echo "打包完成!"
}

if [ ! -e repackimg.sh ]
then
echo "请先cd到当前目录，然后执行./repackimg.sh，不要尝试其他方法！"
return
fi

if [ "$1" == "" ] || [ "$2" == "" ]
then
echo "使用方法：./repackimg.sh [ mtk / common ] ImageFolder"
return
elif [ ! -d $2 ]
then
echo "需要打包的文件夹($2)不存在！"
return
fi

if [ "$repack_type" == "mtk" ]
then
mtk_repackimg
elif [ "$repack_type" == "common" ]
then
common_repackimg
fi

