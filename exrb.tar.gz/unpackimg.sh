#!/system/bin/sh
DATA_WORK=$PWD #当前路径
unpack_type=$1 #第一个参数
file_chosen=$2 #第二个参数
bin=$DATA_WORK/bin #bin目录
bb=$bin/busybox #busybox

#解包mtk的boot/rec
function mtk_unpackimg()
{
cd $DATA_WORK

echo "新建工作文件夹 ${file_chosen%.*} ..."
$bb mkdir ${file_chosen%.*}
cd ${file_chosen%.*}
  
echo "解包中..."
$bin/call $bin unpackimg -i ../$file_chosen -o .
$bb mkdir $file_chosen-ramdisk
cd $file_chosen-ramdisk
#去除512字节
#echo "去除512字节头..."
$bb dd if=../$file_chosen-ramdisk.gz of=../temp-ramdisk.gz bs=512 skip=1 

#echo "检查ramdisk压缩方式..."
$bin/file -m $bin/magic ../temp-ramdisk.gz | $bb cut -d: -f2 | $bb cut -d" " -f2 > ../"$file_chosen-ramdiskcomp";
ramdiskcomp=`cat ../$file_chosen-ramdiskcomp`;
unpackcmd="$bb $ramdiskcomp -dc";
compext=$ramdiskcomp;
case $ramdiskcomp in
  gzip) compext=gz && unpackcmd="gzip -dc";;
  lzop) compext=lzo && unpackcmd="lzop -dc";;
  xz) compext=xz && unpackcmd="xz -dc";;
  lzma|LZMA) compext=lzma && unpackcmd="xz -dc";;
  bzip2) compext=bz2 && unpackcmd="bzip2 -dc";;
  lz4) unpackcmd="$bin/call $bin lz4 -dq"; extra="stdout" && compext=lz4;;
  *) compext="";;
esac;
if [ "$compext" ]; then
  compext=.$compext;
fi;
#不支持的压缩格式
if [ ! "$compext" ]; then
  echo "不支持的压缩格式!";
  return 1;
fi;
echo "ramdisk 压缩方式为 $ramdiskcomp..."
#echo "解压ramdiak..."
#解包命令
$unpackcmd "../temp-ramdisk.gz" $extra | $bb cpio -i;
#失败
if [ $? == "1" ]; then
  echo "解包失败!"
  return 1;
fi;
rm -r ../temp-ramdisk.gz
echo "解包完成!"
}

#解包通用的boot/rec
function common_unpackimg()
{
cd $DATA_WORK
   
echo "新建工作文件夹 ${file_chosen%.*} ..."
$bb mkdir ${file_chosen%.*}
cd ${file_chosen%.*}
    
#echo "解包中..."
$bin/call $bin unpackimg -i ../$file_chosen -o .
$bb mkdir $file_chosen-ramdisk
cd $file_chosen-ramdisk
#echo "检查ramdisk压缩方式..."
$bin/file -m $bin/magic ../*-ramdisk.gz | $bb cut -d: -f2 | $bb cut -d" " -f2 > ../"$file_chosen-ramdiskcomp";
ramdiskcomp=`cat ../$file_chosen-ramdiskcomp`;
unpackcmd="$bb $ramdiskcomp -dc";
compext=$ramdiskcomp;
case $ramdiskcomp in
  gzip) compext=gz && unpackcmd="gzip -dc";;
  lzop) compext=lzo && unpackcmd="lzop -dc";;
  xz) compext=xz && unpackcmd="xz -dc";;
  lzma|LZMA) compext=lzma && unpackcmd="xz -dc";;
  bzip2) compext=bz2 && unpackcmd="bzip2 -dc";;
  lz4) unpackcmd="$bin/call $bin lz4 -dq"; extra="stdout" && compext=lz4;;
  *) compext="";;
esac;
if [ "$compext" ]; then
  compext=.$compext;
fi;
echo "ramdisk 压缩方式为 $ramdiskcomp..."
#echo "解压ramdiak..."
mv "../$file_chosen-ramdisk.gz" "../$file_chosen-ramdisk$compext";
#不支持的压缩格式
if [ ! "$compext" ]; then
  echo "不支持的压缩格式!";
  return 1;
fi;
#解包命令
$unpackcmd "../$file_chosen-ramdisk$compext" $extra | $bb cpio -i;
#失败
if [ $? == "1" ]; then
  echo "解包失败!"
  return 1;
fi;
echo "解包完成!"
}

if [ ! -e unpackimg.sh ]
then
echo "请先cd到当前目录，然后执行./unpackimg.sh，不要尝试其他方法！"
return
fi

if [ "$1" == "" ] || [ "$2" == "" ]
then
echo "使用方法：./unpackimg.sh [ mtk / common ] ImageFile"
return
elif [ ! -f $2 ]
then
echo "需要解包的文件($2)不存在！"
return
fi

if [ "$unpack_type" == "mtk" ]
then
mtk_unpackimg
fi

if [ "$unpack_type" == "common" ]
then
common_unpackimg
fi
