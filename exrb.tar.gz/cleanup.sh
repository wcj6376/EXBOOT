#!/system/bin/env bash
# AIK-Linux/cleanup: reset working directory
# by wcj6376 build 20180715 and thanks author-osm0sis @Q 893919135 or 340132896

case $1 in
  --help) echo "usage: cleanup.sh"; exit 1;
esac;

aik="${BASH_SOURCE:-$0}";
aik="$(dirname "$(readlink -f "$aik")")";

cd "$aik";
if [ ! -z "$(ls ramdisk/* 2>/dev/null)" ] && [ "$(stat -c %U ramdisk/* | head -n 1)" = "root" ]; then
  sudo=sudo;
fi;
$sudo rm -rf ramdisk split_img *new.* *original.*;
echo "Working directory cleaned.";
exit 0;

